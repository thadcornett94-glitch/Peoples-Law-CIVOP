import React, { useState } from 'react';

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  url: string;
  text: string;
}

export const ShareModal: React.FC<ShareModalProps> = ({ isOpen, onClose, url, text }) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleCopy = () => {
    // 1. Try Modern API
    navigator.clipboard.writeText(`${text} ${url}`).then(() => {
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    }).catch(() => {
        // 2. Fallback for strict browsers
        try {
            const input = document.createElement('textarea');
            input.value = `${text} ${url}`;
            document.body.appendChild(input);
            input.select();
            document.execCommand('copy');
            document.body.removeChild(input);
            setCopied(true);
            setTimeout(() => setCopied(false), 2000);
        } catch (e) {
            alert("Please manually copy the link below.");
        }
    });
  };

  // Pre-encode properly for share links
  const encodedUrl = encodeURIComponent(url);
  const encodedText = encodeURIComponent(text);

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-2xl shadow-2xl max-w-sm w-full border border-stone-200 overflow-hidden relative transform transition-all scale-100">
        
        <div className="bg-stone-50 px-6 py-4 border-b border-stone-100 flex items-center justify-between">
            <h3 className="font-serif font-bold text-stone-800">Share The People's Law</h3>
            <button onClick={onClose} className="text-stone-400 hover:text-stone-700">
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
            </button>
        </div>

        <div className="p-6 grid grid-cols-2 gap-4">
            {/* Facebook */}
            <a 
                href={`https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex flex-col items-center gap-2 p-3 rounded-xl border border-stone-100 hover:bg-blue-50 hover:border-blue-200 transition-colors group"
            >
                <div className="w-10 h-10 bg-blue-600 text-white rounded-full flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform">
                    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M9 8h-3v4h3v12h5v-12h3.642l.358-4h-4v-1.667c0-.955.192-1.333 1.115-1.333h2.885v-5h-3.808c-3.596 0-5.192 1.583-5.192 4.615v3.385z"/></svg>
                </div>
                <span className="text-xs font-bold text-stone-600">Facebook</span>
            </a>

            {/* Twitter / X */}
            <a 
                href={`https://twitter.com/intent/tweet?text=${encodedText}&url=${encodedUrl}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex flex-col items-center gap-2 p-3 rounded-xl border border-stone-100 hover:bg-stone-100 hover:border-stone-300 transition-colors group"
            >
                <div className="w-10 h-10 bg-black text-white rounded-full flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform">
                    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
                </div>
                <span className="text-xs font-bold text-stone-600">X (Twitter)</span>
            </a>

            {/* LinkedIn */}
            <a 
                href={`https://www.linkedin.com/sharing/share-offsite/?url=${encodedUrl}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex flex-col items-center gap-2 p-3 rounded-xl border border-stone-100 hover:bg-blue-50 hover:border-blue-200 transition-colors group"
            >
                <div className="w-10 h-10 bg-[#0077b5] text-white rounded-full flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform">
                    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M4.98 3.5c0 1.381-1.11 2.5-2.48 2.5s-2.48-1.119-2.48-2.5c0-1.38 1.11-2.5 2.48-2.5s2.48 1.12 2.48 2.5zm.02 4.5h-5v16h5v-16zm7.982 0h-4.968v16h5v-8.306c0-4.613 5.432-5.185 5.432 0v8.306h5v-10.5c0-5.385-5.492-5.234-7.554-2.617l-.432-2.889z"/></svg>
                </div>
                <span className="text-xs font-bold text-stone-600">LinkedIn</span>
            </a>

            {/* Reddit */}
            <a 
                href={`https://www.reddit.com/submit?url=${encodedUrl}&title=${encodedText}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex flex-col items-center gap-2 p-3 rounded-xl border border-stone-100 hover:bg-orange-50 hover:border-orange-200 transition-colors group"
            >
                <div className="w-10 h-10 bg-[#FF4500] text-white rounded-full flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform">
                    <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M12 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0zm5.01 4.744c.688 0 1.25.561 1.25 1.249a1.25 1.25 0 0 1-2.498.056l-2.597-.547-.8 3.747c1.824.07 3.48.632 4.674 1.488.308-.309.73-.491 1.207-.491.968 0 1.754.786 1.754 1.754 0 .716-.435 1.333-1.01 1.614a3.111 3.111 0 0 1 .042.52c0 2.694-3.13 4.87-7.004 4.87-3.874 0-7.004-2.176-7.004-4.87 0-.183.015-.366.043-.534A1.748 1.748 0 0 1 4.028 12c0-.968.786-1.754 1.754-1.754.463 0 .898.196 1.207.49 1.207-.883 2.878-1.43 4.744-1.487l.885-4.182a.342.342 0 0 1 .14-.197.35.35 0 0 1 .238-.042l2.906.617a1.214 1.214 0 0 1 1.108-.701zM9.25 12C8.561 12 8 12.562 8 13.25c0 .687.561 1.248 1.25 1.248.687 0 1.248-.561 1.248-1.249 0-.688-.561-1.249-1.249-1.249zm5.5 0c-.687 0-1.248.561-1.248 1.25 0 .687.561 1.248 1.249 1.248.688 0 1.249-.561 1.249-1.249 0-.687-.562-1.249-1.25-1.249zm-5.466 3.99a.327.327 0 0 0-.231.094.33.33 0 0 0 0 .463c.842.842 2.484.913 2.961.913.477 0 2.105-.056 2.961-.913a.361.361 0 0 0 .029-.463.33.33 0 0 0-.464 0c-.547.533-1.684.73-2.512.73-.828 0-1.979-.196-2.512-.73a.326.326 0 0 0-.232-.095z"/></svg>
                </div>
                <span className="text-xs font-bold text-stone-600">Reddit</span>
            </a>

            {/* WhatsApp */}
            <a 
                href={`https://wa.me/?text=${encodedText}%20${encodedUrl}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex flex-col items-center gap-2 p-3 rounded-xl border border-stone-100 hover:bg-green-50 hover:border-green-200 transition-colors group"
            >
                <div className="w-10 h-10 bg-[#25D366] text-white rounded-full flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform">
                    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></svg>
                </div>
                <span className="text-xs font-bold text-stone-600">WhatsApp</span>
            </a>

            {/* Email */}
            <a 
                href={`mailto:?subject=Check out The People's Law AI&body=${encodedText} ${encodedUrl}`}
                className="flex flex-col items-center gap-2 p-3 rounded-xl border border-stone-100 hover:bg-amber-50 hover:border-amber-200 transition-colors group"
            >
                <div className="w-10 h-10 bg-amber-600 text-white rounded-full flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform">
                    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>
                </div>
                <span className="text-xs font-bold text-stone-600">Email</span>
            </a>
        </div>

        {/* Copy Link Manual */}
        <div className="p-6 pt-0">
             <div className="relative">
                 <input 
                    type="text" 
                    readOnly
                    value={url}
                    className="w-full pl-4 pr-24 py-3 bg-stone-50 border border-stone-200 rounded-lg text-sm text-stone-500 font-mono"
                 />
                 <button 
                    onClick={handleCopy}
                    className={`absolute right-1 top-1 bottom-1 px-4 rounded-md text-xs font-bold uppercase tracking-wider transition-all ${
                        copied 
                        ? 'bg-green-500 text-white' 
                        : 'bg-stone-800 text-white hover:bg-stone-700'
                    }`}
                 >
                    {copied ? 'Copied!' : 'Copy'}
                 </button>
             </div>
        </div>

      </div>
    </div>
  );
};