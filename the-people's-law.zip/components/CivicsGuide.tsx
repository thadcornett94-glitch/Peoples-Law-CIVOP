import React, { useState } from 'react';

interface CivicsGuideProps {
  onAsk: (prompt: string) => void;
}

export const CivicsGuide: React.FC<CivicsGuideProps> = ({ onAsk }) => {
  const [activeTab, setActiveTab] = useState<'levels' | 'oversight'>('levels');

  return (
    <div className="flex flex-col h-full overflow-y-auto animate-fade-in bg-[#f5f4f1] pb-12">
      <div className="max-w-5xl mx-auto w-full p-4 md:p-12">
        
        {/* Header */}
        <div className="text-center mb-10">
           <div className="inline-flex items-center justify-center p-4 bg-sky-100/80 rounded-full mb-6 shadow-sm ring-1 ring-sky-200">
              <svg className="w-10 h-10 text-sky-800" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
              </svg>
           </div>
           <h1 className="text-3xl md:text-5xl font-serif font-bold text-stone-900 mb-4">Civics & Oversight</h1>
           <p className="text-stone-600 max-w-2xl mx-auto text-lg mb-8">
              Understanding how your government works and your rights to hold it accountable.
           </p>

           <div className="flex justify-center gap-4 mb-8">
              <button
                 onClick={() => setActiveTab('levels')}
                 className={`px-6 py-2 rounded-full font-bold text-sm uppercase tracking-wide transition-all ${
                    activeTab === 'levels' 
                    ? 'bg-stone-800 text-white shadow-md' 
                    : 'bg-white text-stone-500 border border-stone-200 hover:bg-stone-50'
                 }`}
              >
                 Levels of Government
              </button>
              <button
                 onClick={() => setActiveTab('oversight')}
                 className={`px-6 py-2 rounded-full font-bold text-sm uppercase tracking-wide transition-all ${
                    activeTab === 'oversight' 
                    ? 'bg-amber-700 text-white shadow-md' 
                    : 'bg-white text-stone-500 border border-stone-200 hover:bg-stone-50'
                 }`}
              >
                 Your Oversight Rights
              </button>
           </div>
        </div>

        {activeTab === 'levels' && (
           <div className="space-y-8 animate-fade-in-up">
              {/* Federal */}
              <div className="bg-white p-8 rounded-2xl border border-stone-200 shadow-sm relative">
                 <div className="flex items-center justify-between mb-4">
                     <div className="flex items-center gap-4">
                        <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded text-xs font-bold uppercase tracking-wider">National</span>
                        <h2 className="text-2xl font-serif font-bold text-stone-800">Federal Government</h2>
                     </div>
                     <button 
                        onClick={() => onAsk("Analyze the structure and enumerated powers of the Federal Government versus the States.")}
                        className="text-xs font-bold text-purple-700 bg-purple-50 px-3 py-1.5 rounded-lg hover:bg-purple-100 transition-colors uppercase tracking-wider hidden sm:block"
                     >
                        Analyze Structure
                     </button>
                 </div>
                 <p className="text-stone-600 leading-relaxed mb-6">
                    Based in Washington D.C., it handles issues that affect the entire country.
                 </p>
                 <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                    <div className="p-4 bg-stone-50 rounded-xl">
                       <strong className="block text-stone-900 mb-1">Defense & Foreign Policy</strong>
                       <span className="text-stone-500">Military, Treaties, Ambassadors.</span>
                    </div>
                    <div className="p-4 bg-stone-50 rounded-xl">
                       <strong className="block text-stone-900 mb-1">Currency & Trade</strong>
                       <span className="text-stone-500">Printing money, Interstate Commerce.</span>
                    </div>
                    <div className="p-4 bg-stone-50 rounded-xl">
                       <strong className="block text-stone-900 mb-1">Civil Rights</strong>
                       <span className="text-stone-500">Enforcing Constitutional protections.</span>
                    </div>
                 </div>
              </div>

              {/* State */}
              <div className="bg-white p-8 rounded-2xl border border-stone-200 shadow-sm relative">
                 <div className="flex items-center justify-between mb-4">
                     <div className="flex items-center gap-4">
                        <span className="bg-green-100 text-green-800 px-3 py-1 rounded text-xs font-bold uppercase tracking-wider">Regional</span>
                        <h2 className="text-2xl font-serif font-bold text-stone-800">State Government</h2>
                     </div>
                     <button 
                        onClick={() => onAsk("Analyze the powers reserved to the States under the 10th Amendment and their impact on daily life.")}
                        className="text-xs font-bold text-purple-700 bg-purple-50 px-3 py-1.5 rounded-lg hover:bg-purple-100 transition-colors uppercase tracking-wider hidden sm:block"
                     >
                        Analyze Powers
                     </button>
                 </div>
                 <p className="text-stone-600 leading-relaxed mb-6">
                    Based in your State Capital (e.g., Sacramento, Austin), it holds broadly shared powers under the 10th Amendment.
                 </p>
                 <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                    <div className="p-4 bg-stone-50 rounded-xl">
                       <strong className="block text-stone-900 mb-1">Criminal Law</strong>
                       <span className="text-stone-500">Most crimes (theft, murder) are state laws.</span>
                    </div>
                    <div className="p-4 bg-stone-50 rounded-xl">
                       <strong className="block text-stone-900 mb-1">Education & Health</strong>
                       <span className="text-stone-500">Funding schools, Medicaid, Hospitals.</span>
                    </div>
                    <div className="p-4 bg-stone-50 rounded-xl">
                       <strong className="block text-stone-900 mb-1">Licenses</strong>
                       <span className="text-stone-500">Drivers licenses, Bar exams, Medical boards.</span>
                    </div>
                 </div>
              </div>

              {/* Local */}
              <div className="bg-stone-800 text-white p-8 rounded-2xl shadow-xl relative overflow-hidden">
                 <div className="absolute top-0 right-0 p-12 opacity-5">
                    <svg className="w-64 h-64" fill="currentColor" viewBox="0 0 24 24"><path d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" /></svg>
                 </div>
                 <div className="relative z-10">
                    <div className="flex items-center gap-4 mb-4 justify-between">
                        <div className="flex items-center gap-4">
                            <span className="bg-amber-600 text-white px-3 py-1 rounded text-xs font-bold uppercase tracking-wider">Community</span>
                            <h2 className="text-2xl font-serif font-bold">Local Government</h2>
                        </div>
                         <button 
                            onClick={() => onAsk("Analyze the impact of local government decisions (Zoning, Police Funding) on individual civil liberties.")}
                            className="text-xs font-bold text-amber-200 bg-white/10 px-3 py-1.5 rounded-lg hover:bg-white/20 transition-colors uppercase tracking-wider hidden sm:block"
                         >
                            Analyze Impact
                         </button>
                    </div>
                    <p className="text-stone-300 leading-relaxed mb-6 max-w-2xl">
                        Often ignored, your City Council, County Commission, and School Board have the most direct impact on your daily life.
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-sm text-stone-900">
                        <div className="p-4 bg-white rounded-xl">
                            <strong className="block mb-1">Police & Fire</strong>
                            <span className="text-stone-500">Funding and overseeing local departments.</span>
                        </div>
                        <div className="p-4 bg-white rounded-xl">
                            <strong className="block mb-1">Zoning & Housing</strong>
                            <span className="text-stone-500">Deciding what can be built in your neighborhood.</span>
                        </div>
                        <div className="p-4 bg-white rounded-xl">
                            <strong className="block mb-1">Roads & Trash</strong>
                            <span className="text-stone-500">Potholes, garbage collection, water.</span>
                        </div>
                        <div className="p-4 bg-white rounded-xl">
                            <strong className="block mb-1">Schools</strong>
                            <span className="text-stone-500">Curriculum, budgets, and policies.</span>
                        </div>
                    </div>
                    <button 
                       onClick={() => onAsk("How do I find out who my local city council members are and when they meet?")}
                       className="mt-6 inline-flex items-center gap-2 text-amber-400 font-bold hover:text-amber-300"
                    >
                       Ask The People's Law how to find your local reps
                       <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                       </svg>
                    </button>
                 </div>
              </div>
           </div>
        )}

        {activeTab === 'oversight' && (
           <div className="space-y-6 animate-fade-in-up">
              <div className="p-6 bg-amber-50 rounded-2xl border border-amber-200">
                 <h2 className="text-xl font-serif font-bold text-amber-900 mb-2">Government in the Sunshine</h2>
                 <p className="text-amber-800 leading-relaxed">
                    In the United States, transparency is a right, not a privilege. Laws known as "Sunshine Laws" require government business to be conducted in public.
                 </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                 {/* Open Meetings */}
                 <div className="bg-white p-6 rounded-2xl border border-stone-200 hover:border-amber-300 transition-colors">
                    <div className="w-12 h-12 bg-stone-100 rounded-full flex items-center justify-center mb-4">
                       <svg className="w-6 h-6 text-stone-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                       </svg>
                    </div>
                    <h3 className="text-lg font-bold text-stone-800 mb-2">Attend Public Meetings</h3>
                    <p className="text-stone-600 text-sm mb-4">
                       City Council, School Board, and Planning Commission meetings are generally required to be open to the public. You have the right to attend and usually the right to speak during "Public Comment."
                    </p>
                    <div className="flex gap-2">
                        <button 
                            onClick={() => onAsk("Analyze the importance of Open Meeting Laws to democratic accountability.")}
                            className="text-xs bg-purple-100 text-purple-800 font-bold px-3 py-1.5 rounded-lg hover:bg-purple-200 uppercase tracking-wider"
                        >
                            Analyze
                        </button>
                        <button 
                           onClick={() => onAsk("What are my rights to speak at a public city council meeting? Explain the Brown Act (California) or similar Open Meeting laws.")}
                           className="text-amber-700 text-sm font-bold flex items-center gap-1 hover:underline"
                        >
                           Ask about Laws
                        </button>
                    </div>
                 </div>

                 {/* Public Records */}
                 <div className="bg-white p-6 rounded-2xl border border-stone-200 hover:border-amber-300 transition-colors">
                    <div className="w-12 h-12 bg-stone-100 rounded-full flex items-center justify-center mb-4">
                       <svg className="w-6 h-6 text-stone-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                       </svg>
                    </div>
                    <h3 className="text-lg font-bold text-stone-800 mb-2">Access Public Records (FOIA)</h3>
                    <p className="text-stone-600 text-sm mb-4">
                       You have the right to request documents, emails, and data from the government. At the federal level, this is <strong>FOIA</strong>. States have their own Public Records Acts.
                    </p>
                    <div className="flex gap-2">
                         <button 
                            onClick={() => onAsk("Analyze the Freedom of Information Act (FOIA). What are the key exemptions the government can use to deny requests?")}
                            className="text-xs bg-purple-100 text-purple-800 font-bold px-3 py-1.5 rounded-lg hover:bg-purple-200 uppercase tracking-wider"
                        >
                            Analyze
                        </button>
                        <button 
                           onClick={() => onAsk("How do I submit a FOIA request? What information do I need to include?")}
                           className="text-amber-700 text-sm font-bold flex items-center gap-1 hover:underline"
                        >
                           How to Request
                        </button>
                    </div>
                 </div>
              </div>
           </div>
        )}

      </div>
    </div>
  );
};