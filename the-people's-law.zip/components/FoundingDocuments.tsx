import React, { useState } from 'react';
import { FOUNDING_DOCUMENTS, CONSTITUTIONAL_SECTIONS, US_CONSTITUTION_TEXT } from '../constants';
import { Bookmark } from '../types';

interface FoundingDocumentsProps {
  onSelectDoc: (prompt: string) => void;
  bookmarks: Bookmark[];
  onToggleBookmark: (item: Bookmark) => void;
}

export const FoundingDocuments: React.FC<FoundingDocumentsProps> = ({ onSelectDoc, bookmarks, onToggleBookmark }) => {
  const [viewMode, setViewMode] = useState<'cards' | 'reader'>('cards');
  const [activeSectionId, setActiveSectionId] = useState<string>('preamble');

  const scrollToSection = (id: string) => {
    setActiveSectionId(id);
    const element = document.getElementById(`doc-section-${id}`);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const isBookmarked = (id: string) => bookmarks.some(b => b.id === id);

  return (
    <div className="flex flex-col h-full overflow-y-auto animate-fade-in bg-[#f5f4f1] pb-12">
      <div className="max-w-6xl mx-auto w-full p-4 md:p-12">
        
        <div className="text-center mb-10">
           <div className="inline-flex items-center justify-center p-4 bg-amber-900/10 rounded-full mb-6 shadow-sm ring-1 ring-amber-900/20">
              <svg className="w-10 h-10 text-amber-900" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
              </svg>
           </div>
           <h1 className="text-3xl md:text-5xl font-serif font-bold text-stone-900 mb-4">Founding Documents & Texts</h1>
           <p className="text-stone-600 max-w-2xl mx-auto text-lg mb-8">
              The original charters, books, and essays that established the rights of the people.
           </p>
           
           {/* View Toggle */}
           <div className="inline-flex bg-white p-1 rounded-xl border border-stone-200 shadow-sm mb-6">
              <button 
                onClick={() => setViewMode('cards')}
                className={`px-6 py-2 rounded-lg text-sm font-bold uppercase tracking-wider transition-all ${
                    viewMode === 'cards' 
                    ? 'bg-stone-900 text-white shadow-md' 
                    : 'text-stone-500 hover:text-stone-900 hover:bg-stone-100'
                }`}
              >
                 Library & Analysis
              </button>
              <button 
                onClick={() => setViewMode('reader')}
                className={`px-6 py-2 rounded-lg text-sm font-bold uppercase tracking-wider transition-all flex items-center gap-2 ${
                    viewMode === 'reader' 
                    ? 'bg-amber-800 text-white shadow-md' 
                    : 'text-stone-500 hover:text-stone-900 hover:bg-stone-100'
                }`}
              >
                 <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                 </svg>
                 Read Constitution
              </button>
           </div>
        </div>

        {viewMode === 'cards' ? (
            <div className="animate-fade-in-up">
                {/* Major Documents Cards */}
                <div className="grid grid-cols-1 gap-8 mb-16">
                    {FOUNDING_DOCUMENTS.map((doc) => {
                        const saved = isBookmarked(doc.id);
                        return (
                            <div key={doc.id} className="bg-white rounded-xl border border-stone-200 overflow-hidden hover:shadow-xl transition-all duration-300 group relative">
                                <div className="md:flex">
                                    <div className="p-8 md:w-2/3">
                                        <div className="flex justify-between items-start mb-2">
                                            <div className="flex items-center gap-3">
                                                <span className="text-xs font-bold uppercase tracking-wider bg-stone-100 text-stone-600 px-2 py-1 rounded">
                                                    {doc.year}
                                                </span>
                                                <h2 className="text-2xl font-serif font-bold text-stone-900 group-hover:text-amber-800 transition-colors">
                                                    {doc.title}
                                                </h2>
                                            </div>
                                            {/* Bookmark Button */}
                                            <button
                                                onClick={(e) => {
                                                    e.stopPropagation();
                                                    onToggleBookmark({
                                                        id: doc.id,
                                                        type: 'doc',
                                                        title: doc.title,
                                                        prompt: doc.prompt,
                                                        subtitle: doc.year,
                                                        timestamp: Date.now()
                                                    });
                                                }}
                                                className={`p-2 rounded-lg transition-all ${saved ? 'text-amber-600 bg-amber-100' : 'text-stone-300 hover:text-amber-500 hover:bg-amber-50'}`}
                                                title={saved ? "Remove from Briefcase" : "Save to Briefcase"}
                                            >
                                                <svg className="w-5 h-5" fill={saved ? "currentColor" : "none"} viewBox="0 0 24 24" stroke="currentColor">
                                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" />
                                                </svg>
                                            </button>
                                        </div>

                                        <p className="text-stone-600 leading-relaxed mb-6">
                                            {doc.description}
                                        </p>
                                        
                                        <div className="mb-6">
                                            <h4 className="text-xs font-bold text-stone-400 uppercase tracking-widest mb-2">Did You Know?</h4>
                                            <ul className="list-disc list-inside text-sm text-stone-500 space-y-1">
                                                {doc.facts.map((fact, idx) => (
                                                    <li key={idx}>{fact}</li>
                                                ))}
                                            </ul>
                                        </div>

                                        <button 
                                            onClick={() => onSelectDoc(doc.prompt)}
                                            className="inline-flex items-center gap-2 px-6 py-3 bg-stone-900 text-white rounded-lg font-bold text-sm uppercase tracking-wide hover:bg-amber-800 transition-colors"
                                        >
                                            Analyze & Discuss
                                            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                                            </svg>
                                        </button>
                                    </div>
                                    
                                    {/* Decorative Side Panel */}
                                    <div className="hidden md:block md:w-1/3 bg-[#f3f0e8] border-l border-stone-200 p-8 flex flex-col justify-center items-center text-center relative">
                                        <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/aged-paper.png')]"></div>
                                        <span className="font-serif text-6xl text-stone-300 font-bold opacity-50 select-none">
                                            {doc.year}
                                        </span>
                                        <div className="mt-4 w-12 h-1 bg-amber-800/20 rounded-full"></div>
                                    </div>
                                </div>
                            </div>
                        );
                    })}
                </div>

                {/* Constitutional Clause Analyzer */}
                <div>
                    <div className="flex items-center gap-4 mb-6">
                        <div className="h-px bg-stone-300 flex-1"></div>
                        <h2 className="text-xl font-serif font-bold text-stone-800 uppercase tracking-widest">Constitutional Clause Analyzer</h2>
                        <div className="h-px bg-stone-300 flex-1"></div>
                    </div>
                    <p className="text-center text-stone-500 mb-8 max-w-2xl mx-auto">
                        Select a specific Article or Amendment for a detailed, clause-by-clause legal breakdown.
                    </p>

                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
                        {CONSTITUTIONAL_SECTIONS.map((section) => (
                            <button
                                key={section.id}
                                onClick={() => onSelectDoc(section.prompt)}
                                className="bg-white p-5 rounded-xl border border-stone-200 shadow-sm hover:shadow-md hover:border-amber-400 hover:bg-amber-50/50 transition-all text-left group"
                            >
                                <span className="block text-xs font-bold uppercase tracking-wider text-stone-400 group-hover:text-amber-600 mb-1">
                                    {section.title}
                                </span>
                                <h3 className="font-serif font-bold text-stone-800 text-lg group-hover:text-amber-900">
                                    {section.subtitle}
                                </h3>
                            </button>
                        ))}
                    </div>
                </div>
            </div>
        ) : (
            // READER VIEW
            <div className="bg-white rounded-2xl shadow-xl border border-stone-200 overflow-hidden flex flex-col md:flex-row h-[70vh] animate-fade-in-up">
                
                {/* Navigation Sidebar */}
                <div className="w-full md:w-64 bg-stone-50 border-b md:border-b-0 md:border-r border-stone-200 overflow-y-auto">
                    <div className="p-4 border-b border-stone-200 bg-stone-100 sticky top-0">
                        <h3 className="font-bold text-stone-800 uppercase tracking-wide text-xs">Table of Contents</h3>
                    </div>
                    <div className="p-2 space-y-1">
                        {US_CONSTITUTION_TEXT.map((section) => (
                            <button
                                key={section.id}
                                onClick={() => scrollToSection(section.id)}
                                className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-colors ${
                                    activeSectionId === section.id 
                                    ? 'bg-amber-100 text-amber-900 font-bold' 
                                    : 'text-stone-600 hover:bg-stone-100'
                                }`}
                            >
                                {section.title}
                            </button>
                        ))}
                    </div>
                </div>

                {/* Content Area */}
                <div className="flex-1 overflow-y-auto bg-white p-8 md:p-12 relative scroll-smooth bg-[url('https://www.transparenttextures.com/patterns/aged-paper.png')]">
                    <div className="max-w-3xl mx-auto space-y-12">
                        {US_CONSTITUTION_TEXT.map((section) => (
                            <section key={section.id} id={`doc-section-${section.id}`} className="scroll-mt-6">
                                <div className="mb-4 pb-2 border-b border-stone-100">
                                    <h2 className="text-2xl font-serif font-bold text-stone-900">{section.title}</h2>
                                    {section.subtitle && (
                                        <h3 className="text-stone-500 font-medium italic">{section.subtitle}</h3>
                                    )}
                                </div>
                                <div className="font-serif text-lg leading-loose text-stone-800 whitespace-pre-wrap">
                                    {section.content}
                                </div>
                                {section.id !== 'amendments_11_27' && (
                                    <button 
                                        onClick={() => onSelectDoc(`Explain ${section.title} of the Constitution in detail.`)}
                                        className="mt-4 text-xs font-bold text-amber-700 uppercase tracking-wider flex items-center gap-1 hover:underline"
                                    >
                                        Ask The People's Law to Analyze this Section
                                        <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                                        </svg>
                                    </button>
                                )}
                            </section>
                        ))}
                    </div>
                    
                    {/* Watermark/Footer */}
                    <div className="mt-20 pt-8 border-t border-stone-100 text-center opacity-40">
                         <p className="font-serif italic text-stone-400">United States Constitution</p>
                    </div>
                </div>
            </div>
        )}

      </div>
    </div>
  );
};